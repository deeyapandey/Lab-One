// ParentClass.java
class ParentClass {
    public void display() {
        System.out.println("Display method in ParentClass");
    }
}
