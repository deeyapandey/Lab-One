// Vehicle.java
class Vehicle {
    public void startEngine() {
        System.out.println("Engine started");
    }
}
